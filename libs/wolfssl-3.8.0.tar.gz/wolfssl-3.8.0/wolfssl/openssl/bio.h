/* bio.h for openssl */


#ifndef WOLFSSL_BIO_H_
#define WOLFSSL_BIO_H_

#include <wolfssl/openssl/ssl.h>


#ifdef __cplusplus
    extern "C" {
#endif




#ifdef __cplusplus
    }  /* extern "C" */ 
#endif


#endif /* WOLFSSL_BIO_H_ */

